# bashcookbook-examples

Welcome to the examples from the _bash Cookbook_.
* http://oreilly.com/catalog/bashckbk/
  * http://examples.oreilly.com/bashckbk/
* http://bashcookbook.com/

Each sub-directory contains the important, long, or difficult-to-type
examples from the relevant chapter.

`./settings`, however, is special. It contains a collection of sample
configuration files, see `./settings/README` and chapter 16 for details.
