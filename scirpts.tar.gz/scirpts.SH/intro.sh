#!/bin/bash
echo "Hello World"
echo $(which neqn)
cat $(which neqn)
