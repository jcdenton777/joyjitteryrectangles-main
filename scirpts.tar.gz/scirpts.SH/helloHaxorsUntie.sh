#! /user/bin/

# This is my first bash script.  Wish me luck!

echo "Hello Haxorz...Now helloHaxorsUntie!"

chmod 755 helloHaxorsUntie